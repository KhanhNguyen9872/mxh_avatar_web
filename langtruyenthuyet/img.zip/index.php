<?PHP
Define('_IN_JOHNCMS', 1);
Require('../incfiles/core.php');
$headmod = 'Làng cổ';
$textl = 'Làng Truyền Thuyết';
Require('../incfiles/head.php');
Include('hoisinh.php');
if (!$user_id){
Header("Location: /");
exit;
}
Echo '<div class="box_forums"><br/><div class="homeforum"><div class="icon-home"><div class="home">Làng Truyền Thuyết</div></div></div></div><div class="phdr">Làng Truyền Thuyết</div>';
Echo'<link rel="stylesheet" href="game.css" type="text/css" />
<div class="bautroiboss">
<br><img src="img/sun1.png"><br>
<img src="img/chimtinhanh.png">
<div class="hangraoboss"></div>
<div class="datboss">
<img src="img/caydua.png">
<a href="npc.php"><img src="img/npcsoi.png"></a>
<img src="img/caydua.png">';
//Hiển thị Avatar 
//Update nơi đang online và tọa độ
mysql_query("UPDATE `vitri` SET `time`='".time()."',`online`='".$textl."',`toado`='".$toado."' WHERE `user_id`='".$user_id."'");
$time=time()-300;
//Bắt đầu cho hiện avatar
$req=mysql_query("SELECT * FROM `vitri` WHERE `online`='".$textl."' AND `time`>'".$time."'");

while($pr = mysql_fetch_array($req))
    {
$name=mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id`='".$pr[user_id]."'"));
$flip=rand(1,2);
if($flip==1) {$flip=' class="flip"';}
else {$flip='';}
        Echo'<a href="/member/'.$pr['user_id'].'.html"><label style="display: inline-block;text-align: center;"><img src="/avatar/'.$pr[user_id].'.png"></label></a>';
    }
//End avatar
Echo'<div class="buico"></div>
</div></div>';
Require('../incfiles/end.php');
?>